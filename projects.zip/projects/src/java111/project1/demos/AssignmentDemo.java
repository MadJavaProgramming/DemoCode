/** Demonstrate assigning values to variables and displaying them
 *  @author Paula Waite
 */
 public class AssignmentDemo {
     /** Create an int variable and a String variable, assign
      *  values to them, and then display.
      */
      public static void main(String[] args) {
          int myNumber = 500;
          String myString = "Hello Everyone!";

          System.out.println("myNumber is " + myNumber);
          System.out.println("myString is " + myString);
      }


 }
