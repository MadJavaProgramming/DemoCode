/** Demonstrates a println and main method.
 *  This is the first class we are writing this semester
 */
public class MyFirstApp {
    /** main method will write out message to the console
    */
    public static void main(String[] args) {
        System.out.println("This is the first class I've written");
    }
}
